local ADDON_NAME, addonTable = ...
addonTable = addonTable or WoWTranslatorNS -- clientes < 3.0 no pasan argumentos
local L = addonTable.L
local AddTooltip = addonTable.AddTooltip
local MARGIN_X = addonTable.MARGIN_X

-- ==========================================
-- VISTA: GENERAL
-- ==========================================
-- Los ajustes que un jugador toca de verdad: activar, color, idioma
-- destino, jerga en otros idiomas y el botón de prueba.

-- código = { nombre en inglés, nombre nativo }
local LANGUAGES = {
    esES = { "Spanish (ES)", "Español (ES)" }, esMX = { "Spanish (AL)", "Español (AL)" },
    enUS = { "English", "English" }, deDE = { "German", "Deutsch" },
    frFR = { "French", "Français" }, itIT = { "Italian", "Italiano" },
    ptBR = { "Portuguese", "Português" }, ruRU = { "Russian", "Русский" },
    koKR = { "Korean", "한국어" }, zhCN = { "Chinese (S)", "简体中文" },
    zhTW = { "Chinese (T)", "繁體中文" }, plPL = { "Polish", "Polski" },
    svSE = { "Swedish", "Svenska" }, noNO = { "Norwegian", "Norsk" },
    trTR = { "Turkish", "Türkçe" }, jaJP = { "Japanese", "日本語" },
    arSA = { "Arabic", "العربية" }, hiIN = { "Hindi", "हिन्दी" },
    thTH = { "Thai", "ไทย" }, viVN = { "Vietnamese", "Tiếng Việt" },
    csCZ = { "Czech", "Čeština" }, nlNL = { "Dutch", "Nederlands" },
    roRO = { "Romanian", "Română" }, huHU = { "Hungarian", "Magyar" },
    elGR = { "Greek", "Ελληνικά" }, ukUA = { "Ukrainian", "Українська" },
    daDK = { "Danish", "Dansk" }, fiFI = { "Finnish", "Suomi" },
    skSK = { "Slovak", "Slovenčina" }, bgBG = { "Bulgarian", "Български" },
    hrHR = { "Croatian", "Hrvatski" }, srRS = { "Serbian", "Српски" },
    slSI = { "Slovenian", "Slovenščina" }, ltLT = { "Lithuanian", "Lietuvių" },
    lvLV = { "Latvian", "Latviešu" }, etEE = { "Estonian", "Eesti" },
    idID = { "Indonesian", "Bahasa Indonesia" }, msMY = { "Malay", "Bahasa Melayu" },
    faIR = { "Persian", "فارسی" }, heIL = { "Hebrew", "עברית" },
    bnBD = { "Bengali", "বাংলা" }, urPK = { "Urdu", "اردو" },
    taIN = { "Tamil", "தமிழ்" }, teIN = { "Telugu", "తెలుగు" },
}

-- Idiomas cuyo nombre nativo NO puede dibujar la fuente de un cliente cualquiera:
-- usan otro alfabeto, o diacríticos fuera de lo que cubre la fuente del juego.
-- Para estos se muestra el nombre en inglés y no un montón de cuadraditos.
local UNRENDERABLE = {
    ruRU = true, ukUA = true, bgBG = true, srRS = true, -- cirílico
    elGR = true,                                        -- griego
    zhCN = true, zhTW = true, koKR = true, jaJP = true, -- CJK
    arSA = true, faIR = true, urPK = true,              -- árabe
    heIL = true,                                        -- hebreo
    hiIN = true, bnBD = true, taIN = true, teIN = true, -- índicos
    thTH = true,                                        -- tailandés
    viVN = true,                                        -- latino, pero con diacríticos que la fuente no cubre
}

-- El idioma del propio cliente siempre en nativo: esa fuente sabe dibujarlo por
-- definición. El resto, nativo si su alfabeto es seguro.
local function LanguageName(code)
    local names = code and LANGUAGES[code]
    if not names then return nil end
    if code == GetLocale() or not UNRENDERABLE[code] then return names[2] end
    return names[1]
end

-- Ordenar por bytes mandaría "Čeština" detrás de la Z, porque la Č empieza por
-- un byte alto. Solo hace falta plegar la primera letra para que caiga bien.
local SORT_FOLD = {
    ["Á"] = "A", ["À"] = "A", ["Â"] = "A", ["Ä"] = "A", ["Ã"] = "A", ["Å"] = "A",
    ["Ç"] = "C", ["Č"] = "C", ["Ć"] = "C",
    ["É"] = "E", ["È"] = "E", ["Ê"] = "E", ["Ë"] = "E",
    ["Í"] = "I", ["Î"] = "I", ["Ï"] = "I",
    ["Ł"] = "L", ["Ñ"] = "N", ["Ń"] = "N",
    ["Ó"] = "O", ["Ö"] = "O", ["Õ"] = "O", ["Ø"] = "O",
    ["Š"] = "S", ["Ś"] = "S",
    ["Ú"] = "U", ["Ü"] = "U", ["Ű"] = "U",
    ["Ž"] = "Z", ["Ź"] = "Z", ["Ż"] = "Z",
}

local function SortKey(text)
    return (text:gsub("[\194-\244][\128-\191]*", function(char) return SORT_FOLD[char] or char end))
end

-- Arriba del desplegable, separado del resto: el idioma del cliente (y sus
-- variantes, esES/esMX o similares). Es lo que va a elegir casi todo el mundo.
local function SplitLanguages()
    local clientLang = GetLocale():sub(1, 2)
    local preferred, rest = {}, {}

    for code in pairs(LANGUAGES) do
        local list = (code:sub(1, 2) == clientLang) and preferred or rest
        list[#list + 1] = code
    end

    local function byName(a, b) return SortKey(LanguageName(a)) < SortKey(LanguageName(b)) end
    -- Entre las variantes del idioma del cliente manda la exacta: en un cliente
    -- esES, "Español (ES)" va antes que "Español (AL)".
    table.sort(preferred, function(a, b)
        local exact = GetLocale()
        if a == exact or b == exact then return a == exact end
        return byName(a, b)
    end)
    table.sort(rest, byName)

    return preferred, rest
end

-- Se rellena en BuildPreviewSection; la llaman todos los controles que cambian
-- lo que se ve en la vista previa.
local RefreshPreview = function() end

local function BuildTranslationSection(panel, y)
    local enable = CreateFrame("CheckButton", "WT_MainEnableCB", panel, "InterfaceOptionsCheckButtonTemplate")
    enable:SetPoint("TOPLEFT", MARGIN_X, y)
    _G[enable:GetName() .. "Text"]:SetText(L["UI_ENABLE_TEXT"])
    enable:SetChecked(WoWTranslatorDB.enabled)
    AddTooltip(enable, L["TT_ENABLE"])

    -- Frase completa (Core/Templates.lua): depende del interruptor principal.
    local templates = CreateFrame("CheckButton", "WT_TemplatesCB", panel, "InterfaceOptionsCheckButtonTemplate")
    templates:SetPoint("TOPLEFT", MARGIN_X + 20, y - 30)
    _G[templates:GetName() .. "Text"]:SetText(L["UI_TEMPLATES"])
    templates:SetChecked(WoWTranslatorDB.settings.templates)
    templates:SetScript("OnClick", function(self)
        WoWTranslatorDB.settings.templates = self:GetChecked() and true or false
        RefreshPreview()
    end)
    AddTooltip(templates, L["TT_TEMPLATES"])

    local function RefreshDependent()
        local on = WoWTranslatorDB.enabled
        if on then templates:Enable() else templates:Disable() end -- SetEnabled no existe en 2.4.3
        templates:SetAlpha(on and 1 or 0.5)
    end
    enable:SetScript("OnClick", function(self)
        WoWTranslatorDB.enabled = self:GetChecked() and true or false
        RefreshDependent()
        RefreshPreview()
    end)
    RefreshDependent()

    -- Botón del minimapa: LibDBIcon guarda "hide" en su propia tabla. Quien lo
    -- tenga en una barra LDB (Bazooka, Titan Panel...) no necesita los dos.
    local minimap = CreateFrame("CheckButton", "WT_MinimapCB", panel, "InterfaceOptionsCheckButtonTemplate")
    minimap:SetPoint("TOPLEFT", MARGIN_X, y - 60)
    _G[minimap:GetName() .. "Text"]:SetText(L["UI_MINIMAP"])
    minimap:SetChecked(not WoWTranslatorDB.minimap.hide)
    minimap:SetScript("OnClick", function(self)
        WoWTranslatorDB.minimap.hide = not self:GetChecked()
        local LDBIcon = LibStub("LibDBIcon-1.0", true)
        if not LDBIcon then return end
        if WoWTranslatorDB.minimap.hide then LDBIcon:Hide("WoWTranslator") else LDBIcon:Show("WoWTranslator") end
    end)
    AddTooltip(minimap, L["TT_MINIMAP"])

    return y - 100
end

local function BuildColorSection(panel, y)
    local button = CreateFrame("Button", "WT_ColorBtn", panel, "UIPanelButtonTemplate")
    button:SetPoint("TOPLEFT", MARGIN_X + 4, y)
    button:SetWidth(140)
    button:SetHeight(22)
    button:SetText(L["UI_COLOR_BTN"])
    AddTooltip(button, L["TT_COLOR"])

    local preview = panel:CreateTexture(nil, "OVERLAY")
    preview:SetPoint("LEFT", button, "RIGHT", 12, 0)
    preview:SetWidth(20)
    preview:SetHeight(20)

    local function CurrentRGB()
        local hex = WoWTranslatorDB.chatColor or "00ff00"
        return tonumber(hex:sub(1, 2), 16) / 255,
            tonumber(hex:sub(3, 4), 16) / 255,
            tonumber(hex:sub(5, 6), 16) / 255
    end

    local function UpdatePreview()
        addonTable.SetSolidColor(preview, CurrentRGB())
        RefreshPreview()
    end

    button:SetScript("OnClick", function()
        local r, g, b = CurrentRGB()
        addonTable.ShowColorPicker(r, g, b, function(nr, ng, nb)
            WoWTranslatorDB.chatColor = string.format("%02x%02x%02x", nr * 255, ng * 255, nb * 255)
            UpdatePreview()
        end)
    end)
    UpdatePreview()

    return y - 44
end

local function BuildLanguageSection(panel, y)
    local dropdown = CreateFrame("Frame", "WT_LangDrop", panel, "UIDropDownMenuTemplate")
    dropdown:SetPoint("TOPLEFT", MARGIN_X - 12, y)
    addonTable.DropDown(UIDropDownMenu_SetWidth, dropdown, 200)
    AddTooltip(dropdown, L["TT_LANG"])

    -- pairs() daría un orden distinto cada vez que se abre el menú.
    local preferred, rest = SplitLanguages()

    -- El menu tiene un solo nivel, asi que el nivel va fijo y el idioma sale del
    -- cierre de cada entrada: 2.4.3 llama a init(level) y a func(arg1, arg2) sin
    -- el marco delante, y desde 3.0 es init(frame, level) y func(button, ...).
    UIDropDownMenu_Initialize(dropdown, function()
        local function AddEntry(code)
            local info = UIDropDownMenu_CreateInfo()
            info.text = LanguageName(code)
            info.value = code
            info.func = function()
                WoWTranslatorDB.targetLocale = code
                UIDropDownMenu_SetSelectedValue(dropdown, code)
                addonTable.DropDown(UIDropDownMenu_SetText, dropdown, LanguageName(code))
                addonTable.RebuildMasterDict()
                RefreshPreview()
            end
            info.checked = (WoWTranslatorDB.targetLocale == code)
            UIDropDownMenu_AddButton(info, 1)
        end

        for _, code in ipairs(preferred) do AddEntry(code) end

        if #preferred > 0 then
            addonTable.AddDropDownSeparator(1)
        end

        for _, code in ipairs(rest) do AddEntry(code) end
    end)

    UIDropDownMenu_SetSelectedValue(dropdown, WoWTranslatorDB.targetLocale)
    addonTable.DropDown(UIDropDownMenu_SetText, dropdown, LanguageName(WoWTranslatorDB.targetLocale) or "Spanish (ES)")

    return y - 44
end

-- ------------------------------------------
-- VISTA PREVIA
-- ------------------------------------------
-- La misma frase de /wt test pasada por el motor real: enseña el color y el
-- idioma elegidos sin tener que ir al chat. Debajo, cuántos términos hay activos.
local PREVIEW_SAMPLE = "LFM ICC HC 25m Need Tank and Healer"

local function CountKeys(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

-- Términos que aporta el inglés: todo el diccionario activo (propio y Babble).
local function EnglishTermCount()
    return CountKeys(addonTable.MasterDict) + CountKeys(addonTable.MultiWordPatterns)
end

-- Se rellena en BuildSourcesSection: los contadores de cada idioma de jerga
-- cambian con las categorías activas, así que se repintan con la vista previa.
local RefreshSourceCounts = function() end

local function BuildPreviewSection(panel, y)
    local text = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    text:SetPoint("TOPLEFT", MARGIN_X + 8, y - 4)
    text:SetWidth(424)
    text:SetJustifyH("LEFT")

    -- El fondo se estira hasta el final del texto: la frase ocupa 2 o 3 líneas
    -- según el idioma, y con un alto fijo se salía por abajo.
    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", MARGIN_X, y + 4)
    bg:SetPoint("BOTTOMLEFT", text, "BOTTOMLEFT", -8, -8)
    bg:SetWidth(440)
    addonTable.SetSolidColor(bg, 0, 0, 0, 0.35)

    RefreshPreview = function()
        local enabled = WoWTranslatorDB.enabled
        text:SetText(enabled and TranslateChat(PREVIEW_SAMPLE) or PREVIEW_SAMPLE)
        text:SetAlpha(enabled and 1 or 0.5)
        RefreshSourceCounts()
    end
    -- Las casillas de Categorías y Expansiones también cambian el resultado.
    panel:SetScript("OnShow", function() RefreshPreview() end)
    RefreshPreview()

    return y - 70
end

-- ------------------------------------------
-- IDIOMAS DE LA JERGA
-- ------------------------------------------
-- Una fila por idioma: casilla, etiqueta con el código, nombre, BETA si la
-- lista de palabras aún se revisa y, a la derecha, cuántos términos aporta.
local SOURCE_ROWS = {
    { key = "srcEnUS", code = "EN", name = "SRC_ENUS", tt = "TT_SRC_ENUS", color = { 0.20, 0.42, 0.78 } },
    { key = "srcKoKR", code = "KO", name = "SRC_KOKR", tt = "TT_SRC", color = { 0.72, 0.20, 0.30 },
        beta = true, dict = "OrigenKoKR" },
    { key = "srcZhCN", code = "ZH", name = "SRC_ZHCN", tt = "TT_SRC", color = { 0.80, 0.52, 0.10 },
        beta = true, dict = "OrigenZhCN" },
}
local ROW_HEIGHT, ROW_WIDTH = 28, 440

local function BuildSourceRow(panel, y, index, row)
    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", MARGIN_X, y)
    bg:SetWidth(ROW_WIDTH)
    bg:SetHeight(ROW_HEIGHT - 2)
    addonTable.SetSolidColor(bg, 0, 0, 0, index % 2 == 1 and 0.35 or 0.2)

    local cb = CreateFrame("CheckButton", "WT_SrcCB_" .. row.key, panel, "InterfaceOptionsCheckButtonTemplate")
    cb:SetPoint("TOPLEFT", MARGIN_X + 2, y)
    _G[cb:GetName() .. "Text"]:SetText("")
    cb:SetChecked(WoWTranslatorDB.settings[row.key])
    cb:SetScript("OnClick", function(self)
        WoWTranslatorDB.settings[row.key] = self:GetChecked() and true or false
        addonTable.RebuildMasterDict()
        RefreshPreview()
    end)
    AddTooltip(cb, L[row.tt])

    local badge = panel:CreateTexture(nil, "ARTWORK")
    badge:SetPoint("TOPLEFT", MARGIN_X + 34, y - 6)
    badge:SetWidth(24)
    badge:SetHeight(14)
    addonTable.SetSolidColor(badge, row.color[1], row.color[2], row.color[3], 0.9)

    local code = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    code:SetPoint("CENTER", badge, "CENTER", 0, 0)
    code:SetText(row.code)

    local name = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    name:SetPoint("LEFT", badge, "RIGHT", 8, 0)
    name:SetText(L[row.name])

    if row.beta then
        local beta = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
        beta:SetPoint("LEFT", name, "RIGHT", 8, 0)
        beta:SetText("|cffff9933" .. L["UI_BETA"] .. "|r")
    end

    local count = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    count:SetPoint("RIGHT", bg, "RIGHT", -10, 0)
    return count
end

local function BuildSourcesSection(panel, y)
    local desc = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    desc:SetPoint("TOPLEFT", MARGIN_X, y)
    desc:SetWidth(ROW_WIDTH)
    desc:SetJustifyH("LEFT")
    desc:SetText(L["UI_SRC_DESC"])
    y = y - 20

    local counters = {}
    for i, row in ipairs(SOURCE_ROWS) do
        counters[i] = BuildSourceRow(panel, y - (i - 1) * ROW_HEIGHT, i, row)
    end

    RefreshSourceCounts = function()
        for i, row in ipairs(SOURCE_ROWS) do
            local n = row.dict and CountKeys(addonTable[row.dict] or {}) or EnglishTermCount()
            counters[i]:SetText(string.format(L["UI_N_TERMS"], n))
        end
    end
    RefreshSourceCounts()

    return y - #SOURCE_ROWS * ROW_HEIGHT - 12
end

-- ------------------------------------------
-- VALORES POR DEFECTO
-- ------------------------------------------
-- Es destructivo y toca 50 casillas repartidas por cinco vistas, así que pide
-- confirmación. Después recarga la interfaz en vez de refrescar cada widget a
-- mano: los paneles se construyen una sola vez al entrar, y repintarlos todos
-- sería mucho andamiaje para dejar alguno desincronizado de todas formas.
StaticPopupDialogs["WOWTRANSLATOR_RESET"] = {
    text = L["RESET_CONFIRM"],
    -- ACCEPT y CANCEL son cadenas del propio juego: ya vienen traducidas y con
    -- el mismo texto que el resto de diálogos del cliente.
    button1 = ACCEPT,
    button2 = CANCEL,
    OnAccept = function()
        addonTable.ResetDatabase()
        ReloadUI()
    end,
    timeout = 0,       -- una acción destructiva no debe cerrarse sola
    whileDead = true,
    hideOnEscape = true,
    showAlert = true,  -- icono de advertencia
}

-- Al lado del botón de prueba, en la misma fila.
local function BuildResetSection(panel, neighbour)
    local reset = CreateFrame("Button", "WT_ResetBtn", panel, "UIPanelButtonTemplate")
    reset:SetPoint("LEFT", neighbour, "RIGHT", 10, 0)
    reset:SetWidth(180)
    reset:SetHeight(24)
    reset:SetText(L["UI_RESET"])
    reset:SetScript("OnClick", function()
        StaticPopup_Show("WOWTRANSLATOR_RESET")
    end)
    AddTooltip(reset, L["TT_RESET"])
end

function addonTable.CreateGeneralUI(parentCategory)
    local panel = addonTable.CreateOptionsPanel("WoWTranslatorGeneralPanel", L["OPT_GENERAL"])
    local y = addonTable.PanelHeading(panel, L["OPT_GENERAL"], true)

    y = addonTable.SectionHeader(panel, y, L["GEN_HEADER"])
    y = BuildTranslationSection(panel, y)

    y = addonTable.SectionHeader(panel, y, L["UI_COLOR_BTN"])
    y = BuildColorSection(panel, y)

    y = addonTable.SectionHeader(panel, y, L["UI_LANG_LABEL"])
    y = BuildLanguageSection(panel, y)

    y = addonTable.SectionHeader(panel, y, L["UI_PREVIEW"])
    y = BuildPreviewSection(panel, y)

    y = addonTable.SectionHeader(panel, y, L["UI_SRC_LABEL"])
    y = BuildSourcesSection(panel, y)

    local test = CreateFrame("Button", "WT_TestBtn", panel, "UIPanelButtonTemplate")
    test:SetPoint("TOPLEFT", MARGIN_X + 4, y - 4)
    test:SetWidth(180)
    test:SetHeight(24)
    test:SetText(L["UI_TEST_BTN"])
    test:SetScript("OnClick", function() addonTable.RunTest() end)
    AddTooltip(test, L["TT_TEST_BTN"])

    BuildResetSection(panel, test)

    addonTable.RegisterSubcategory(parentCategory, panel)
end
