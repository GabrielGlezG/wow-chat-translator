local ADDON_NAME, addonTable = ...
addonTable = addonTable or WoWTranslatorNS -- clientes < 3.0 no pasan argumentos
addonTable.MidnightDict = {
    ["midnight"] = { esES = "Midnight", esMX = "Midnight", enUS = "Midnight", deDE = "Midnight", frFR = "Midnight", itIT = "Midnight", koKR = "미드나이트", ptBR = "Midnight", ruRU = "Midnight", zhCN = "午夜", zhTW = "午夜", plPL = "Midnight", svSE = "Midnight", noNO = "Midnight", trTR = "Geceyarısı", jaJP = "ミッドナイト", arSA = "منصف الليل", hiIN = "मिडनाइट", thTH = "มิดไนท์", viVN = "Midnight", csCZ = "Midnight", nlNL = "Midnight", roRO = "Midnight", huHU = "Midnight", elGR = "Midnight", ukUA = "Midnight", daDK = "Midnight", fiFI = "Midnight", skSK = "Midnight", bgBG = "Midnight", hrHR = "Midnight", srRS = "Midnight", slSI = "Midnight", ltLT = "Midnight", lvLV = "Midnight", etEE = "Midnight", idID = "Midnight", msMY = "Midnight", faIR = "Midnight", heIL = "Midnight", bnBD = "Midnight", urPK = "Midnight", taIN = "Midnight", teIN = "Midnight" },
}
